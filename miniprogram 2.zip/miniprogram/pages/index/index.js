const store = require('../../utils/store')
const api = require('../../utils/api')
const location = require('../../utils/location')
const scan = require('../../utils/scan')
const navigate = require('../../utils/navigate')

function splitTags(raw, fallback) {
  if (Array.isArray(raw) && raw.length) {
    return raw.map((t) => String(t).trim()).filter(Boolean).slice(0, 3)
  }
  const s = String(raw || '')
    .replace(/[|/、，,]/g, ' ')
    .trim()
  if (!s) return fallback || []
  return s.split(/\s+/).filter(Boolean).slice(0, 3)
}

/** 后端把 city 同时别名成 tag / distance / category，取值需跨槽位去重 */
function firstUnique(candidates, used) {
  for (const raw of candidates) {
    const s = String(raw || '').trim()
    if (!s || used.has(s)) continue
    used.add(s)
    return s
  }
  return ''
}

function uniqueTags(raw, fallback, used) {
  const tags = []
  for (const t of splitTags(raw, [])) {
    if (used.has(t)) continue
    used.add(t)
    tags.push(t)
  }
  if (tags.length) return tags
  return (fallback || []).filter((t) => !used.has(t))
}

function isDistanceText(v) {
  const s = String(v || '')
  return /\d/.test(s) && /(km|m|公里|米)/i.test(s)
}

const CATEGORY_MAP = {
  stall: [
    { id: 'all', label: '全部' },
    { id: '烧烤', label: '烧烤' },
    { id: '小吃', label: '小吃' },
    { id: '主食', label: '主食' },
    { id: '烫捞', label: '烫捞' },
    { id: '饮品', label: '饮品' }
  ],
  cross: [
    { id: 'all', label: '全部' },
    { id: '果切', label: '果切' },
    { id: '茶饮', label: '茶饮' },
    { id: '花艺', label: '花艺' },
    { id: '洗车', label: '洗车' },
    { id: '足道', label: '足道' }
  ],
  supply: [
    { id: 'all', label: '全部' },
    { id: '粮油', label: '粮油' },
    { id: '冻品', label: '冻品' },
    { id: '调味', label: '调味' },
    { id: '耗材', label: '包装' },
    { id: '生鲜', label: '生鲜' }
  ]
}

function cuisineOf(item, tab) {
  const blob = `${item.name || ''} ${item.desc || ''} ${item.descLine || ''} ${item.category || ''}`
  if (tab === 'stall') {
    if (/烤|串/.test(blob)) return '烧烤'
    if (/臭豆腐|豆腐/.test(blob)) return '小吃'
    if (/麻辣烫|烫/.test(blob)) return '烫捞'
    if (/豆浆|茶|饮/.test(blob)) return '饮品'
    return '主食'
  }
  if (tab === 'cross') {
    if (/果/.test(blob)) return '果切'
    if (/奶茶|茶饮|茶/.test(blob)) return '茶饮'
    if (/花/.test(blob)) return '花艺'
    if (/洗车/.test(blob)) return '洗车'
    if (/足/.test(blob)) return '足道'
    return '果切'
  }
  if (/粮油/.test(blob)) return '粮油'
  if (/冻/.test(blob)) return '冻品'
  if (/调味/.test(blob)) return '调味'
  if (/包装|耗材/.test(blob)) return '耗材'
  if (/生鲜/.test(blob)) return '生鲜'
  return '粮油'
}

Page({
  data: {
    headerTop: 92,
    userName: '',
    stalls: [],
    crossStores: [],
    supplyMerchants: [],
    tab: 'stall',
    points: 0,
    cashValue: '0.00',
    displayList: [],
    keyword: '',
    loading: false,
    locationText: '定位中',
    locating: false,
    category: 'all',
    categories: CATEGORY_MAP.stall,
    sort: 'distance'
  },
  onLoad() {
    const sys = wx.getSystemInfoSync()
    const statusBarHeight = sys.statusBarHeight || 44
    let headerTop = statusBarHeight + 48
    try {
      const capsule = wx.getMenuButtonBoundingClientRect()
      if (capsule && capsule.bottom) headerTop = capsule.bottom + 8
    } catch (_) {}
    this.setData({ headerTop })
  },
  async onShow() {
    // 启动页已改为首页：先等自动登录，未登录再进登录页
    try {
      const app = getApp()
      if (app && app.globalData && app.globalData.bootPromise) {
        const boot = await app.globalData.bootPromise
        app.globalData.bootPromise = null
        if (boot && boot.ok && boot.session && boot.session.role && boot.session.role !== 'consumer') {
          store.routeAfterLogin()
          return
        }
      }
    } catch (_) {}
    if (!store.ensureConsumerOrRedirect()) return

    // 定位不阻塞列表：先用缓存坐标出数，定位成功后再刷新距离
    this.reload()
    this.ensureLocation()
      .then(() => this.reload())
      .catch(() => {})
  },
  geoQuery() {
    return location.queryFromSaved()
  },
  syncLocationText() {
    const loc = location.getSaved() || {}
    if (this.data.locating) {
      this.setData({ locationText: '定位中' })
      return
    }
    if (loc.lat == null) {
      this.setData({ locationText: '点击定位' })
      return
    }
    const label = loc.displayCity || loc.city || '当前位置'
    this.setData({ locationText: label })
  },
  async ensureLocation({ force = false } = {}) {
    this.setData({ locating: true })
    this.syncLocationText()
    try {
      await location.locate(api, { force })
      this.setData({ locating: false })
      this.syncLocationText()
      const loc = location.getSaved() || {}
      if (loc.inService === false) {
        wx.showToast({ title: '当前不在开通城市，已按距离展示附近门店', icon: 'none' })
      }
    } catch (e) {
      this.setData({ locating: false })
      this.syncLocationText()
      if (!location.getSaved()) {
        wx.showToast({ title: e.message || '定位失败', icon: 'none' })
      }
      throw e
    }
  },
  async reload() {
    const seq = (this._reloadSeq = (this._reloadSeq || 0) + 1)
    this.setData({ loading: true })
    try {
      const session = await store.refreshProfile().catch(() => store.getSession() || {})
      const q = this.geoQuery()
      const [stalls, crossStores, supplyMerchants, pointsData] = await Promise.all([
        api.stalls(q),
        api.crossStores(q),
        api.supplyMerchants(q).catch(() => []),
        api.myPoints().catch(() => ({ points: session.points || 0, cashValue: 0 }))
      ])
      if (seq !== this._reloadSeq) return
      api.trackVisit({
        roleScope: 'consumer',
        pageKey: 'index',
        city: q.city,
        latitude: q.lat,
        longitude: q.lng
      }).catch(() => {})
      const points = pointsData.points != null ? pointsData.points : store.getConsumerPoints()
      store.setConsumerPoints(points)
      this.syncLocationText()
      const decoratedStalls = location.decorateList(stalls || [])
      const decoratedCross = location.decorateList(crossStores || [])
      const decoratedSupply = location.decorateList(supplyMerchants || [])
      const tab = this.data.tab
      const displayList = this.computeDisplayList(tab, {
        stalls: decoratedStalls,
        crossStores: decoratedCross,
        supplyMerchants: decoratedSupply,
        keyword: this.data.keyword,
        category: this.data.category,
        sort: this.data.sort
      })
      this.setData({
        userName: session.name || '',
        stalls: decoratedStalls,
        crossStores: decoratedCross,
        supplyMerchants: decoratedSupply,
        points,
        cashValue: Number(pointsData.cashValue != null ? pointsData.cashValue : store.pointsToCash(points)).toFixed(2),
        displayList,
        loading: false
      })
    } catch (e) {
      if (seq !== this._reloadSeq) return
      this.setData({ loading: false })
      wx.showToast({ title: e.message || '加载失败', icon: 'none' })
    }
  },
  computeDisplayList(tab, ctx) {
    const kw = String((ctx && ctx.keyword != null ? ctx.keyword : this.data.keyword) || '')
      .trim()
      .toLowerCase()
    const category = (ctx && ctx.category != null ? ctx.category : this.data.category) || 'all'
    const sort = (ctx && ctx.sort != null ? ctx.sort : this.data.sort) || 'distance'
    const stalls = (ctx && ctx.stalls) || this.data.stalls || []
    const crossStores = (ctx && ctx.crossStores) || this.data.crossStores || []
    const supplyMerchants = (ctx && ctx.supplyMerchants) || this.data.supplyMerchants || []
    let list = []
    if (tab === 'stall') {
      list = stalls.map((s) => {
        const used = new Set()
        const priceText = `月售 ${s.sales || 0}`
        used.add(priceText)
        const hint = s.address || s.city || ''
        used.add(hint)
        return {
          ...s,
          itemType: 'stall',
          initial: s.initial || (s.name || '摊').slice(0, 1),
          coverImage: s.coverImage || '',
          badge: s.open === false ? '休息中' : '夜市招牌',
          rating: Number(s.rating || 4.8).toFixed(1),
          descLine: firstUnique([s.desc, s.category, '夜市美食'], used),
          distanceText: firstUnique([isDistanceText(s.distance) ? s.distance : ''], used),
          priceText,
          dealLine: '消费得积分 · 可兑附近异业',
          tags: uniqueTags(s.tags || s.tag, ['夜市', '现做'], used),
          hint,
          cuisine: cuisineOf(s, 'stall'),
          salesNum: Number(s.sales || 0),
          ratingNum: Number(s.rating || 4.8),
          distanceKm: s.distanceKm == null ? null : Number(s.distanceKm),
          cta: '去点餐'
        }
      })
    } else if (tab === 'cross') {
      list = crossStores.map((s) => {
        const used = new Set()
        const priceText = '积分可兑'
        used.add(priceText)
        const hint = s.address || s.city || ''
        used.add(hint)
        return {
          ...s,
          itemType: 'cross',
          initial: s.initial || (s.name || '异').slice(0, 1),
          coverImage: s.coverImage || '',
          badge: '积分兑换',
          rating: Number(s.rating || 4.7).toFixed(1),
          descLine: firstUnique([s.category, '异业门店'], used),
          distanceText: firstUnique([isDistanceText(s.distance) ? s.distance : ''], used),
          priceText,
          dealLine: '积分抵现 · 不够可补现金',
          tags: uniqueTags(s.tags || s.category, ['异业', '可兑'], used),
          hint,
          cuisine: cuisineOf(s, 'cross'),
          salesNum: Number(s.sales || 0),
          ratingNum: Number(s.rating || 4.7),
          distanceKm: s.distanceKm == null ? null : Number(s.distanceKm),
          cta: '去兑换'
        }
      })
    } else {
      list = supplyMerchants.map((s) => {
        const used = new Set()
        const priceText = `在售 ${s.goodsCount || 0} SKU`
        used.add(priceText)
        const hint = s.address || s.city || ''
        used.add(hint)
        return {
          ...s,
          itemType: 'supply',
          initial: s.initial || (s.name || '供').slice(0, 1),
          coverImage: s.coverImage || '',
          badge: '供应链',
          rating: '',
          descLine: firstUnique(['原料配送', s.city], used),
          distanceText: firstUnique([isDistanceText(s.distance) ? s.distance : ''], used),
          priceText,
          dealLine: '批发配送 · 可提交采购需求',
          tags: uniqueTags(s.tags, ['供货', '批发'], used),
          hint,
          cuisine: cuisineOf(s, 'supply'),
          salesNum: Number(s.goodsCount || 0),
          ratingNum: 0,
          distanceKm: s.distanceKm == null ? null : Number(s.distanceKm),
          cta: '提需求'
        }
      })
    }
    if (category && category !== 'all') {
      list = list.filter((s) => s.cuisine === category)
    }
    if (kw) {
      list = list.filter((s) => {
        const blob = `${s.name || ''} ${s.hint || ''} ${s.descLine || ''} ${(s.tags || []).join(' ')}`.toLowerCase()
        return blob.indexOf(kw) >= 0
      })
    }
    list = list.slice().sort((a, b) => {
      if (sort === 'rating') return (b.ratingNum || 0) - (a.ratingNum || 0)
      if (sort === 'sales') return (b.salesNum || 0) - (a.salesNum || 0)
      const da = a.distanceKm == null || Number.isNaN(a.distanceKm) ? Number.POSITIVE_INFINITY : a.distanceKm
      const db = b.distanceKm == null || Number.isNaN(b.distanceKm) ? Number.POSITIVE_INFINITY : b.distanceKm
      return da - db
    })
    return list
  },
  buildDisplayList(tab) {
    this.setData({ displayList: this.computeDisplayList(tab) })
  },
  onSort(e) {
    const sort = e.currentTarget.dataset.sort
    if (!sort || sort === this.data.sort) return
    this.setData({ sort })
    this.buildDisplayList(this.data.tab)
  },
  onTab(e) {
    const tab = e.currentTarget.dataset.tab
    if (!tab || tab === this.data.tab) return
    this.setData({
      tab,
      category: 'all',
      categories: CATEGORY_MAP[tab] || CATEGORY_MAP.stall
    })
    this.buildDisplayList(tab)
  },
  onCategory(e) {
    const id = e.currentTarget.dataset.id
    if (!id || id === this.data.category) return
    this.setData({ category: id })
    this.buildDisplayList(this.data.tab)
  },
  async onRelocate() {
    if (this.data.locating) return
    wx.showLoading({ title: '定位中' })
    await this.ensureLocation({ force: true })
    wx.hideLoading()
    await this.reload()
  },
  onSearchInput(e) {
    this.setData({ keyword: e.detail.value || '' })
  },
  onSearchConfirm() {
    this.buildDisplayList(this.data.tab)
    if (!this.data.displayList.length) {
      wx.showToast({ title: '未找到相关门店', icon: 'none' })
    }
  },
  onScan() {
    wx.scanCode({
      scanType: ['qrCode'],
      success: (result) => {
        const stallId = scan.extractStallId(result)
        if (!stallId) {
          wx.showToast({ title: '未识别到有效摊位码', icon: 'none' })
          return
        }
        wx.navigateTo({ url: scan.scanPayUrl(stallId) })
      },
      fail: (error) => {
        if (String(error.errMsg || '').indexOf('cancel') < 0) {
          wx.showToast({ title: '扫码失败，请重试', icon: 'none' })
        }
      }
    })
  },
  openItem(e) {
    const { id, type } = e.currentTarget.dataset
    if (type === 'cross') {
      wx.navigateTo({ url: `/pages/cross-detail/cross-detail?id=${id}` })
    } else if (type === 'supply') {
      wx.navigateTo({ url: `/pages/supply-need/supply-need?vendorId=${id}` })
    } else {
      wx.navigateTo({ url: `/pages/stall-menu/stall-menu?id=${id}` })
    }
  },
  onNavigate(e) {
    navigate.openFromDataset(e.currentTarget.dataset, this.data.displayList)
  },
  goPoints() {
    wx.switchTab({ url: '/pages/points/points' })
  },
  goOrders() {
    wx.navigateTo({ url: '/pages/orders/orders' })
  },
  goRecommend() {
    wx.navigateTo({ url: '/pages/recommend/recommend' })
  },
  goApply() {
    wx.navigateTo({ url: '/pages/apply/apply' })
  },
  goSupplyNeed() {
    wx.navigateTo({ url: '/pages/supply-need/supply-need' })
  }
})
