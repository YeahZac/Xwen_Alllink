const api = require('../../utils/api')
const { mergeBanners } = require('../../utils/banner-pack')

const SLOTS = {
  index: [1, 10],
  cross: [10, 20],
  points: [20, 30],
  mine: [30, 40]
}

function pickRows(rows, pageKey) {
  const list = Array.isArray(rows) ? rows : []
  if (!pageKey) return list
  if (list.some((row) => row && row.pageKey)) {
    return list.filter((row) => row.pageKey === pageKey)
  }
  const band = SLOTS[pageKey]
  if (!band) return list
  return list.filter((row) => {
    const sort = Number(row && row.sortOrder)
    return sort >= band[0] && sort < band[1]
  })
}

Component({
  properties: {
    role: {
      type: String,
      value: 'consumer'
    },
    pageKey: {
      type: String,
      value: ''
    },
    height: {
      type: Number,
      value: 280
    }
  },
  data: {
    list: [],
    current: 0
  },
  observers: {
    'role, pageKey'() {
      this.load()
    }
  },
  lifetimes: {
    attached() {
      this.load()
    }
  },
  methods: {
    async load() {
      const scope = this.properties.role || 'consumer'
      const pageKey = this.properties.pageKey || ''
      let rows = []
      try {
        rows = await api.banners(scope, pageKey)
      } catch (_) {
        rows = []
      }
      const picked = pageKey ? pickRows(rows, pageKey) : rows
      this.setData({
        list: picked.length ? mergeBanners(scope, picked) : [],
        current: 0
      })
    },
    onImgError(e) {
      const idx = e.currentTarget.dataset.index
      this.setData({ [`list[${idx}].imgError`]: true })
    },
    onChange(e) {
      this.setData({ current: e.detail.current })
    },
    onTap(e) {
      const idx = e.currentTarget.dataset.index
      const item = this.data.list[idx]
      if (!item || !item.link || item.linkType === 'none') {
        return
      }
      const link = String(item.link)
      if (
        item.linkType === 'switchTab' ||
        link.indexOf('/pages/index/') === 0 ||
        link.indexOf('/pages/cross/') === 0 ||
        link.indexOf('/pages/points/') === 0 ||
        link.indexOf('/pages/mine/') === 0
      ) {
        wx.switchTab({ url: link.split('?')[0] })
      } else if (item.linkType === 'navigate' || link.charAt(0) === '/') {
        wx.navigateTo({
          url: link,
          fail: () => wx.switchTab({ url: link.split('?')[0], fail: () => {} })
        })
      }
    }
  }
})
