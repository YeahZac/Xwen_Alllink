/**
 * 将本地图片压缩到指定大小以内，便于云托管 callContainer 上传。
 * 注意：base64 会膨胀约 4/3，callContainer 整包常有 ~1MB 限制，
 * 因此默认目标取 600KB，避免 -606001。
 */
const DEFAULT_MAX = 600 * 1024
const RETRY_MAX = 400 * 1024

function getFileSize(filePath) {
  return new Promise((resolve, reject) => {
    wx.getFileSystemManager().getFileInfo({
      filePath,
      success: (r) => resolve(Number(r.size) || 0),
      fail: (e) => reject(new Error((e && e.errMsg) || '无法读取图片大小'))
    })
  })
}

function compressOnce(src, { quality, compressedWidth } = {}) {
  return new Promise((resolve, reject) => {
    if (!wx.compressImage) {
      reject(new Error('当前基础库不支持图片压缩，请更换较小照片'))
      return
    }
    const opts = {
      src,
      quality: quality != null ? quality : 70,
      success: (r) => resolve(r.tempFilePath || src),
      fail: (e) => reject(new Error((e && e.errMsg) || '图片压缩失败'))
    }
    if (compressedWidth) opts.compressedWidth = compressedWidth
    wx.compressImage(opts)
  })
}

/**
 * @param {string} filePath
 * @param {number} [maxBytes]
 * @returns {Promise<{ filePath: string, size: number, compressed: boolean }>}
 */
async function compressUnderLimit(filePath, maxBytes = DEFAULT_MAX) {
  let path = filePath
  let size = await getFileSize(path)
  if (size <= maxBytes) {
    return { filePath: path, size, compressed: false }
  }

  // 先降边长，再降画质（证照仍需可读）
  const widths = maxBytes <= 80 * 1024 ? [1280, 1024, 800, 640, 480, 360] : [1600, 1280, 1024, 800]
  const qualities = maxBytes <= 80 * 1024 ? [70, 55, 40, 30, 20, 15] : [80, 70, 60, 50, 40, 30, 20]

  for (const w of widths) {
    for (const q of qualities) {
      try {
        path = await compressOnce(path, { quality: q, compressedWidth: w })
      } catch (_) {
        path = await compressOnce(path, { quality: q })
      }
      size = await getFileSize(path)
      if (size <= maxBytes) {
        return { filePath: path, size, compressed: true }
      }
    }
  }

  if (size > maxBytes) {
    throw new Error(`图片压缩后仍超过 ${Math.round(maxBytes / 1024)}KB，请换一张更小的照片`)
  }
  return { filePath: path, size, compressed: true }
}

module.exports = {
  DEFAULT_MAX,
  RETRY_MAX,
  getFileSize,
  compressUnderLimit
}
